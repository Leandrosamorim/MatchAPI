﻿namespace Domain.DeveloperMatchNS.Queries
{
    public class DeveloperMatchQuery
    {
        public Guid? DeveloperUId { get; set; }
        public Guid? OrganizationUId { get; set; }
    }
}
